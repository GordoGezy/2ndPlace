﻿using UnityEngine;
using System.Collections;

public class OnClickDisableObj : MonoBehaviour {

	
	void OnClick() {
	    this.gameObject.SetActive(false);
	}
	}
