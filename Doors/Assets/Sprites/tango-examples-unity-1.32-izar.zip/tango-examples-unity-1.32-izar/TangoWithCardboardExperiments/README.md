TangoWithCardboardExperiments
===========================================
Copyright (C) 2016 Google Inc.

Contents
--------
This contains the virtual reality example project using Tango and Cardboard Unity SDK. Example project is for Unity 5 and above.

Please note that this project removed google-unity-wrapper plug-in in TangoSDK in order to resolve the conflict between CardboardSDK and TangoSDK. This may cause issues if your project is depends on the google-unity-wrapper plug-in.

Please see the full tutorial [here](https://developers.google.com/project-tango/apis/unity/unity-cardboard-integration).
